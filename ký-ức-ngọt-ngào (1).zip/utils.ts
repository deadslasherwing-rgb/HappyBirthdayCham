/**
 * Converts various Google Drive link formats into a direct image source URL.
 * This allows users to simply paste a "Share" link from Google Drive.
 */
export const getDirectImageSrc = (url: string | undefined): string | undefined => {
    if (!url) return undefined;

    // Check if it's a Google Drive link
    if (url.includes('drive.google.com') || url.includes('docs.google.com')) {
        // Extract the ID
        let id = '';
        const parts = url.split('/');
        
        // Handle format: .../d/FILE_ID/view...
        const dIndex = parts.indexOf('d');
        if (dIndex !== -1 && parts.length > dIndex + 1) {
            id = parts[dIndex + 1];
        } 
        // Handle format: id=FILE_ID
        else if (url.includes('id=')) {
            const match = url.match(/id=([a-zA-Z0-9_-]+)/);
            if (match && match[1]) {
                id = match[1];
            }
        }

        if (id) {
            // Return the direct download/view URL
            return `https://drive.google.com/uc?export=view&id=${id}`;
        }
    }

    // Return original URL if no conversion needed
    return url;
};